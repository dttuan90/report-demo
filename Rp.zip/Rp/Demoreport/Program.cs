﻿// See https://aka.ms/new-console-template for more information

using System.Collections;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;

var data = new Dictionary<string, object>()
{
    { "STT", new {Value = "aaaa", Style = 0} },
    { "Name", new {Value = "Test 1", Style = 1} },
    { "Sum", new {Value = 300, Style = 1} },
    { "AAA", new {Value = 100, Style = 2} },
    { "BBB", new {Value = 100, Style = 3} },
    { "CCC", new {Value = 100, Style = 0} },
};
var data2 = new Dictionary<string, object>()
{
    { "STT", new {Value = "aaaa", Style = 0} },
    { "Name", new {Value = "Test 2", Style = 1} },
    { "Sum", new {Value = 600, Style = 1} },
    { "AAA", new {Value = 200, Style = 2} },
    { "BBB", new {Value = 200, Style = 3} },
    { "CCC", new {Value = 200, Style = 0} },
};
var data3 = new Dictionary<string, object>()
{
    { "STT", new {Value = "aaaa", Style = 0} },
    { "Name", new {Value = "Test 3", Style = 1} },
    { "Sum", new {Value = 900, Style = 1} },
    { "AAA", new {Value = 300, Style = 2} },
    { "BBB", new {Value = 300, Style = 3} },
    { "CCC", new {Value = 300, Style = 0} },
};

var lstData = new List<Dictionary<string, object>>();
lstData.Add(data);
lstData.Add(data2);
lstData.Add(data3);



var templateFileName = "C:\\Users\\trant\\Desktop\\Test\\template01.xlsx";
var outputFile = "C:\\Users\\trant\\Desktop\\Test\\tmp.xlsx";

using var fs = new FileStream(templateFileName, FileMode.Open, FileAccess.Read);
XSSFWorkbook wb = new XSSFWorkbook(fs);
var sheet = wb.GetSheetAt(0);

// Dòng bắt đầu insert
var startRow = 1;

IRow templateRow = sheet.GetRow(startRow);
int cellCount = templateRow.LastCellNum;

var boldFont = wb.CreateFont();
boldFont.FontName = "Times New Roman";
boldFont.IsBold = true;

var italicFont = wb.CreateFont();
italicFont.FontName = "Times New Roman";
italicFont.IsItalic = true;

var boldItalicFont = wb.CreateFont();
boldItalicFont.FontName = "Times New Roman";
boldItalicFont.IsBold = true;
boldItalicFont.IsItalic = true;

int startItem = 0;
// For item trong list data báo cáo đã query
for (int i = startRow; i <= lstData.Count() + startRow - 1; i++)
{
    // Copy dòng hiện tại
    if (i < lstData.Count() + startRow - 1)
    {
        sheet.CopyRow(i, i + 1);
    }

    // Insert data đã tính toán vào row hiện tại
    var curRow = sheet.GetRow(i);
    for (int j = 0; j < cellCount; j++)
    {
        var curCell = curRow.GetCell(j);
        BindDataAndStyleToRow(curCell, lstData[startItem].ElementAt(j).Value, true);
    }
    startItem++;
}

wb.Write(new FileStream(outputFile, FileMode.CreateNew));

void BindDataAndStyleToRow(ICell cell, dynamic data, bool isTmp)
{
    cell.SetCellValue(data.Value);
    cell.SetCellType(CellType.String);

    if (data.Style == 1)
    {
        CellUtil.SetFont(cell, boldFont);
    }
    else if (data.Style == 2)
    {
        CellUtil.SetFont(cell, italicFont);
    }
    else if (data.Style == 3)
    {
        CellUtil.SetFont(cell, boldItalicFont);
    }
}